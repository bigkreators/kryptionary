<?php

namespace MediaWiki\TimedMediaHandler\Handlers\OggHandler;

use Exception;

class OggException extends Exception {
}
