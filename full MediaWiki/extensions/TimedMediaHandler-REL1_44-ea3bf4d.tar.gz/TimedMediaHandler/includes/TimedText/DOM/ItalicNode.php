<?php

namespace MediaWiki\TimedMediaHandler\TimedText\DOM;

/**
 * WebVTT Class object, maps roughly to an HTML i.
 */
class ItalicNode extends InternalNode {
	//
}
