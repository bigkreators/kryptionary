<?php

namespace MediaWiki\TimedMediaHandler\TimedText\DOM;

/**
 * WebVTT Ruby object, maps roughly to an HTML rt.
 */
class RubyTextNode extends InternalNode {
	//
}
