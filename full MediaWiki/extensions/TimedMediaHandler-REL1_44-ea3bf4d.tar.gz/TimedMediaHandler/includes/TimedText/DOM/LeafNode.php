<?php

namespace MediaWiki\TimedMediaHandler\TimedText\DOM;

/**
 * WebVTT Leaf node parent class, maps to an HTML text node or weird annotation.
 */
class LeafNode extends Node {
	//
}
