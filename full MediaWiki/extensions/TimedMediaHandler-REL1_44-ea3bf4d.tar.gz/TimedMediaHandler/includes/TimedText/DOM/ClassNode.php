<?php

namespace MediaWiki\TimedMediaHandler\TimedText\DOM;

/**
 * WebVTT Class object, maps roughly to an HTML span.
 */
class ClassNode extends InternalNode {
	//
}
