<?php

namespace MediaWiki\TimedMediaHandler\TimedText\DOM;

/**
 * WebVTT Underline object, maps roughly to an HTML u.
 */
class UnderlineNode extends InternalNode {
	//
}
